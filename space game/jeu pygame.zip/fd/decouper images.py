from PIL import Image

def decouper_image(image_path, largeur, hauteur, dossier_sortie):
    # Ouvrir l'image avec Pillow
    image = Image.open(image_path)
    
    # Obtenir la taille totale de l'image
    largeur_totale, hauteur_totale = image.size
    
    # Calculer le nombre de morceaux en largeur et en hauteur
    nb_morceaux_largeur = largeur_totale // largeur
    nb_morceaux_hauteur = hauteur_totale // hauteur
    
    # Découper l'image en morceaux
    for i in range(nb_morceaux_largeur):
        for j in range(nb_morceaux_hauteur):
            # Coordonnées du coin supérieur gauche du morceau
            x1 = i * largeur
            y1 = j * hauteur
            
            # Coordonnées du coin inférieur droit du morceau
            x2 = x1 + largeur
            y2 = y1 + hauteur
            
            # Découper le morceau
            morceau = image.crop((x1, y1, x2, y2))
            
            # Sauvegarder le morceau dans le dossier de sortie
            nom_fichier = f"explosion_bonus_{i}.png"  # Utiliser i et j pour le nom de fichier
            chemin_sortie = f"{dossier_sortie}/{nom_fichier}"
            morceau.save(chemin_sortie)

# Exemple d'utilisation
image_path = "skin/explosion_bonus.png"
dossier_sortie = "skin"

decouper_image(image_path, 65, 80, dossier_sortie)
