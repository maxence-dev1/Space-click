
                    self.ecran.fill((0,0,0))